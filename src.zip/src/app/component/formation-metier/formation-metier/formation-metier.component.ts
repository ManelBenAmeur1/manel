import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-formation-metier',
  templateUrl: './formation-metier.component.html',
  styleUrls: ['./formation-metier.component.css']
})
export class FormationMetierComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
