import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { FormationMetierComponent } from './formation-metier/formation-metier.component';
import { AddFormationComponent } from './add-formation/add-formation.component';

const routes: Routes = [

{
        path: 'formationMetiers',
        component: FormationMetierComponent,
        children: [
            {
                path: 'add',
                component: AddFormationComponent
            }

        ]
    }

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class FormationMEtierRoutingModule { }
