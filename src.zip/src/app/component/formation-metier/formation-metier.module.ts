import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FormationMEtierRoutingModule } from './formation-metier-routing.module';
import { FormationMetierComponent } from './formation-metier/formation-metier.component';
import { AddFormationComponent } from './add-formation/add-formation.component';


@NgModule({
  declarations: [FormationMetierComponent, AddFormationComponent],
  imports: [
    CommonModule,
    FormationMEtierRoutingModule
  ]
})
export class FormationMEtierModule { }
