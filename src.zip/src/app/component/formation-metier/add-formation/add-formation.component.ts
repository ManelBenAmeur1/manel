import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-formation',
  templateUrl: './add-formation.component.html',
  styleUrls: ['./add-formation.component.css']
})
export class AddFormationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
